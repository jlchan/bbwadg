-- Copyright 2012 by Till Tantau
--
-- This file may be distributed an/or modified
--
-- 1. under the LaTeX Project Public License and/or
-- 2. under the GNU Public License
--
-- See the file doc/generic/pgf/licenses/LICENSE for more information

--- @release $Header: /cvsroot/pgf/pgf/generic/pgf/graphdrawing/lua/pgf/gd/routing.lua,v 1.1 2014/02/24 10:40:32 tantau Exp $



local routing = {}

-- Declare namespace
require("pgf.gd").routing = routing


-- Done

return routing